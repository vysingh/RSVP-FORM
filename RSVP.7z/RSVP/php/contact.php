<?php
   $fname = $_POST['firstname'];
   $lname = $_POST['lastname'];
   $gender = $_POST['gender'];
   $email = $_POST['email'];
   $numberofpeople = $_POST['numberofpeople'];
   $arriving = $_POST['arriving'];
   $leaving = $_POST['leaving'];
   $message = $_POST['message'];
   $to = 'abc@def.com';
 $subject = "{Confirm} $fname $lname";
   $body = "From: $fname $lname\n Gender: $gender\n E-Mail: $email\n Number of people: $numberofpeople\n Arriving: $arriving\n Leaving: $leaving\n Message: $message";

   if ($_POST['submit']) {
       if (mail ($to, $subject, $body)) {
     echo "Hello, $fname. Your message has been sent. Thank you.";
 } else {
     echo '<p>Oops! Something went wrong, please go back and try again.</p>';
 }
   }
?>
